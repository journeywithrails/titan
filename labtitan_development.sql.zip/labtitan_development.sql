-- phpMyAdmin SQL Dump
-- version 2.8.2
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: May 20, 2009 at 09:11 AM
-- Server version: 5.0.22
-- PHP Version: 5.1.4
-- 
-- Database: `labtitan_development`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `accessioning_sites`
-- 

CREATE TABLE `accessioning_sites` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  `address` text,
  `city` varchar(255) default NULL,
  `state` varchar(255) default NULL,
  `zipcode` int(11) default NULL,
  `phone` int(11) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `accessioning_sites`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `cases`
-- 

CREATE TABLE `cases` (
  `id` int(11) NOT NULL auto_increment,
  `case_number` int(11) default NULL,
  `patient_id` int(11) default NULL,
  `room_number` int(11) default NULL,
  `facility_id` int(11) default NULL,
  `physician_id` int(11) default NULL,
  `accessionedby` varchar(255) default NULL,
  `accessioned_fromIP` varchar(255) default NULL,
  `accession_time` datetime default NULL,
  `pickup_time` datetime default NULL,
  `received_time` datetime default NULL,
  `gross_time` datetime default NULL,
  `processor_time` datetime default NULL,
  `embed_time` datetime default NULL,
  `cut_time` datetime default NULL,
  `stain_time` datetime default NULL,
  `casetype_id` int(11) default NULL,
  `container_count` int(11) default NULL,
  `specimen_type_id` int(11) default NULL,
  `specimen_source` text,
  `gross_dictation_id` int(11) default NULL,
  `micro_dictation_id` int(11) default NULL,
  `path_test_id` int(11) default NULL,
  `stains_ordered_ids` text,
  `files` varchar(255) default NULL,
  `gross_dictation_transcription` text,
  `micro_dictation_transcription` text,
  `diagnosis_dictation_transcription` text,
  `pathology_tests` text,
  `diagnosis` text,
  `status` varchar(255) default NULL,
  `stage` varchar(255) default NULL,
  `processing_lab_site_id` int(11) default NULL,
  `assigned_pathologist` varchar(255) default NULL,
  `bill_to` text,
  `subscriber_first_name` varchar(255) default NULL,
  `subscriber_last_name` varchar(255) default NULL,
  `primary_insurance_id` int(11) default NULL,
  `secondary_insurance_id` int(11) default NULL,
  `primary_care_physician_id` int(11) default NULL,
  `medical_record_number` int(11) default NULL,
  `cassette_numbers` text,
  `slide_numbers` text,
  `notes` text,
  `comments` text,
  `completed_report_id` int(11) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `cases`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `completed_reports`
-- 

CREATE TABLE `completed_reports` (
  `id` int(11) NOT NULL auto_increment,
  `case_id` int(11) default NULL,
  `last_printed` datetime default NULL,
  `filename` varchar(255) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `completed_reports`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `departments`
-- 

CREATE TABLE `departments` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  `description` text,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

-- 
-- Dumping data for table `departments`
-- 

INSERT INTO `departments` VALUES (1, 'Accessioning', NULL);
INSERT INTO `departments` VALUES (2, 'Gross', NULL);
INSERT INTO `departments` VALUES (3, 'Histology', NULL);
INSERT INTO `departments` VALUES (4, 'Cytology', NULL);
INSERT INTO `departments` VALUES (5, 'Pathology', NULL);
INSERT INTO `departments` VALUES (6, 'Courier', NULL);
INSERT INTO `departments` VALUES (7, 'Transcription', NULL);
INSERT INTO `departments` VALUES (8, 'Client Services', NULL);
INSERT INTO `departments` VALUES (9, 'Billing', NULL);

-- --------------------------------------------------------

-- 
-- Table structure for table `diagnosis_dictations`
-- 

CREATE TABLE `diagnosis_dictations` (
  `id` int(11) NOT NULL auto_increment,
  `case_id` int(11) default NULL,
  `dictated_by` varchar(255) default NULL,
  `assigned_transciptionist` text,
  `transcribed_text` text,
  `transcription_assigned_time` datetime default NULL,
  `transcription_completed_time` datetime default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `diagnosis_dictations`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `diagnosis_types`
-- 

CREATE TABLE `diagnosis_types` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  `description` text,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `diagnosis_types`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `facilities`
-- 

CREATE TABLE `facilities` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  `address` text,
  `city` varchar(255) default NULL,
  `state` varchar(255) default NULL,
  `zip_code` varchar(255) default NULL,
  `phone` int(11) default NULL,
  `fax` int(11) default NULL,
  `facility_type_id` int(11) default NULL,
  `notes` text,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `facilities`
-- 

INSERT INTO `facilities` VALUES (1, 'test', 'test', 'test', 'test', '34234234', 234234234, 243234234, 2, 'test', '2009-05-19 00:02:06', '2009-05-19 00:32:17');

-- --------------------------------------------------------

-- 
-- Table structure for table `facilities_physicians`
-- 

CREATE TABLE `facilities_physicians` (
  `facility_id` int(11) default NULL,
  `physician_id` int(11) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `facilities_physicians`
-- 

INSERT INTO `facilities_physicians` VALUES (1, 2);

-- --------------------------------------------------------

-- 
-- Table structure for table `facility_types`
-- 

CREATE TABLE `facility_types` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

-- 
-- Dumping data for table `facility_types`
-- 

INSERT INTO `facility_types` VALUES (1, 'Hospital', NULL, NULL);
INSERT INTO `facility_types` VALUES (2, 'Clinic', NULL, NULL);
INSERT INTO `facility_types` VALUES (3, 'Laboratory', NULL, NULL);
INSERT INTO `facility_types` VALUES (4, 'Misc', NULL, NULL);
INSERT INTO `facility_types` VALUES (5, 'privatepractice', NULL, NULL);

-- --------------------------------------------------------

-- 
-- Table structure for table `gross_dictations`
-- 

CREATE TABLE `gross_dictations` (
  `id` int(11) NOT NULL auto_increment,
  `case_id` int(11) default NULL,
  `user_id` int(11) default NULL,
  `assigned_transciptionist` text,
  `transcribed_text` text,
  `transcription_assigned_time` datetime default NULL,
  `transcription_completed_time` datetime default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `gross_dictations`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `images`
-- 

CREATE TABLE `images` (
  `id` int(11) NOT NULL auto_increment,
  `case_id` int(11) default NULL,
  `dictated_by` varchar(255) default NULL,
  `assigned_transciptionist` text,
  `transcribed_text` text,
  `transcription_assigned_time` datetime default NULL,
  `transcription_completed_time` datetime default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `images`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `insurances`
-- 

CREATE TABLE `insurances` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  `address` text,
  `city` varchar(255) default NULL,
  `state` varchar(255) default NULL,
  `zipcode` int(11) default NULL,
  `phone` int(11) default NULL,
  `upin` int(11) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `insurances`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `micro_dictations`
-- 

CREATE TABLE `micro_dictations` (
  `id` int(11) NOT NULL auto_increment,
  `case_id` int(11) default NULL,
  `dictated_by` varchar(255) default NULL,
  `assigned_transciptionist` text,
  `transcribed_text` text,
  `transcription_assigned_time` datetime default NULL,
  `transcription_completed_time` datetime default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `micro_dictations`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `path_tests`
-- 

CREATE TABLE `path_tests` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  `description` text,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `path_tests`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `patients`
-- 

CREATE TABLE `patients` (
  `id` int(11) NOT NULL auto_increment,
  `social_security` varchar(255) default NULL,
  `date_of_birth` date default NULL,
  `first_name` varchar(255) default NULL,
  `last_name` varchar(255) default NULL,
  `middle_initial` varchar(255) default NULL,
  `suffix` varchar(255) default NULL,
  `sex` varchar(255) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `patients`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `physician_staff_members`
-- 

CREATE TABLE `physician_staff_members` (
  `id` int(11) NOT NULL auto_increment,
  `first_name` varchar(255) default NULL,
  `last_name` varchar(255) default NULL,
  `middle_initial` varchar(255) default NULL,
  `cell_phone` int(11) default NULL,
  `facility_id` int(11) default NULL,
  `physician_id` int(11) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `physician_staff_members`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `physicians`
-- 

CREATE TABLE `physicians` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  `last_name` varchar(255) default NULL,
  `middle_initial` varchar(255) default NULL,
  `cell_phone` int(11) default NULL,
  `route_id` int(11) default NULL,
  `physician_staff_members` text,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- 
-- Dumping data for table `physicians`
-- 

INSERT INTO `physicians` VALUES (2, 'first physician', 'last physician', 'm', 924859687, 1, NULL, '2009-05-19 17:27:52', '2009-05-19 17:27:52');

-- --------------------------------------------------------

-- 
-- Table structure for table `processing_lab_sites`
-- 

CREATE TABLE `processing_lab_sites` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  `address` text,
  `city` varchar(255) default NULL,
  `state` varchar(255) default NULL,
  `zipcode` int(11) default NULL,
  `phone` int(11) default NULL,
  `subnet` varchar(255) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `processing_lab_sites`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `roles`
-- 

CREATE TABLE `roles` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

-- 
-- Dumping data for table `roles`
-- 

INSERT INTO `roles` VALUES (1, 'Pathologist');
INSERT INTO `roles` VALUES (2, 'Pathologist Assistant');
INSERT INTO `roles` VALUES (3, 'Histology Assistant');
INSERT INTO `roles` VALUES (4, 'Histologist');
INSERT INTO `roles` VALUES (5, 'Histology Supervisor');
INSERT INTO `roles` VALUES (6, 'Gross Assistant');
INSERT INTO `roles` VALUES (7, 'Gross Supervisor');
INSERT INTO `roles` VALUES (8, 'Transcriptionist');
INSERT INTO `roles` VALUES (9, 'TranscriptionistSupervisor');
INSERT INTO `roles` VALUES (10, 'Cytology Assistant');
INSERT INTO `roles` VALUES (11, 'Cytologist');
INSERT INTO `roles` VALUES (12, 'Cytology Supervisor');
INSERT INTO `roles` VALUES (13, 'Courier');
INSERT INTO `roles` VALUES (14, 'Courier Supervisor');
INSERT INTO `roles` VALUES (15, 'Cytology Supervisor');
INSERT INTO `roles` VALUES (16, 'Client Service');
INSERT INTO `roles` VALUES (17, 'Billing');
INSERT INTO `roles` VALUES (18, 'Billing Supervisor');

-- --------------------------------------------------------

-- 
-- Table structure for table `routes`
-- 

CREATE TABLE `routes` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  `description` text,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `routes`
-- 

INSERT INTO `routes` VALUES (1, 'router name', 'testing router', '2009-05-19 17:27:52', '2009-05-19 17:27:52');

-- --------------------------------------------------------

-- 
-- Table structure for table `schema_migrations`
-- 

CREATE TABLE `schema_migrations` (
  `version` varchar(255) NOT NULL,
  UNIQUE KEY `unique_schema_migrations` (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `schema_migrations`
-- 

INSERT INTO `schema_migrations` VALUES ('20090518151946');
INSERT INTO `schema_migrations` VALUES ('20090518160143');
INSERT INTO `schema_migrations` VALUES ('20090518160236');
INSERT INTO `schema_migrations` VALUES ('20090518160333');
INSERT INTO `schema_migrations` VALUES ('20090518160435');
INSERT INTO `schema_migrations` VALUES ('20090518160514');
INSERT INTO `schema_migrations` VALUES ('20090518160615');
INSERT INTO `schema_migrations` VALUES ('20090518160714');
INSERT INTO `schema_migrations` VALUES ('20090518160740');
INSERT INTO `schema_migrations` VALUES ('20090518160815');
INSERT INTO `schema_migrations` VALUES ('20090518160911');
INSERT INTO `schema_migrations` VALUES ('20090518161109');
INSERT INTO `schema_migrations` VALUES ('20090518161138');
INSERT INTO `schema_migrations` VALUES ('20090518161208');
INSERT INTO `schema_migrations` VALUES ('20090518161249');
INSERT INTO `schema_migrations` VALUES ('20090518161339');
INSERT INTO `schema_migrations` VALUES ('20090518161420');
INSERT INTO `schema_migrations` VALUES ('20090518161454');
INSERT INTO `schema_migrations` VALUES ('20090518161527');
INSERT INTO `schema_migrations` VALUES ('20090518161554');
INSERT INTO `schema_migrations` VALUES ('20090518161634');
INSERT INTO `schema_migrations` VALUES ('20090518192753');

-- --------------------------------------------------------

-- 
-- Table structure for table `stains`
-- 

CREATE TABLE `stains` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  `description` text,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `stains`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `users`
-- 

CREATE TABLE `users` (
  `id` int(11) NOT NULL auto_increment,
  `email` varchar(255) NOT NULL,
  `first_name` varchar(255) default NULL,
  `last_name` varchar(255) default NULL,
  `password_salt` varchar(255) default NULL,
  `password_hash` varchar(255) default NULL,
  `department_id` int(11) default NULL,
  `role_id` int(11) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

-- 
-- Dumping data for table `users`
-- 

INSERT INTO `users` VALUES (1, 'admin@admin.com', 'admin', 'admin', '384435600.765759094864647', '49a03b4208ff3480085a4302543c89b5db652aac', 1, 2, '2009-05-18 07:00:00', '2009-05-18 07:00:00');
INSERT INTO `users` VALUES (2, 'examination@user.com', 'Examination', 'Examination', '352709400.743098325736572', 'd1ec3220ebeb596756b4a74b11148a3a449b9212', 5, 1, '2009-05-19 07:00:00', '2009-05-19 07:00:00');
INSERT INTO `users` VALUES (3, 'grossing@user.com', 'Grossing', 'Grossing', '364979800.426686483400042', '21abc3d074073f503f0579178fda8811b235ae3c', 2, 7, '2009-05-19 07:00:00', '2009-05-19 07:00:00');
INSERT INTO `users` VALUES (4, 'processing@user.com', 'processing', 'processing', '382125600.176149404444579', '39b4a01fa5c141f5861a4bca64e4c100ba19fff5', 7, 8, '2009-05-19 07:00:00', '2009-05-19 07:00:00');
INSERT INTO `users` VALUES (5, 'client@labtitan.com', 'test client', 'client', '336415400.643009464762598', '24dbe0e82322123c0edd31088e7b5568e38f470b', 8, 16, '2009-05-20 07:00:00', '2009-05-20 07:00:00');
